import Link from "next/link";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <div className="brand-mark" style={{ color: "#F7EFE4", marginBottom: 14 }}>
              <img src="/images/logo-badge.png" alt="Velluvia" className="brand-badge" />
              <span>VELLUVIA</span>
            </div>
            <p style={{ maxWidth: 260 }}>
              Thoughtful gifts, curated with care and delivered with purpose — for corporate
              milestones and personal moments alike.
            </p>
          </div>

          <div>
            <h4>Shop</h4>
            <Link href="/collections/signature">Signature Gifting</Link>
            <Link href="/collections/luxe">Velluvia Luxe</Link>
            <Link href="/collections/office">Velluvia Office</Link>
            <Link href="/collections/home">Velluvia Home</Link>
          </div>

          <div>
            <h4>Company</h4>
            <Link href="/about">Our Story</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/delivery">Delivery &amp; Shipping</Link>
            <Link href="/cart">Cart</Link>
            <Link href="/account">Your Orders</Link>
            <a href="mailto:hello@velluvia.co.uk">hello@velluvia.co.uk</a>
            <a href="tel:+447480854250">07480 854250</a>
            <p style={{ margin: "2px 0" }}>Facebook: Velluvia Gifting</p>
            <p style={{ margin: "2px 0" }}>Instagram: @velluvia.co.uk</p>
            <p style={{ margin: "2px 0" }}>TikTok: @velluvia.co.uk</p>
          </div>

          <div>
            <h4>Legal</h4>
            <Link href="/privacy-policy">Privacy Policy</Link>
            <Link href="/terms-conditions">Terms &amp; Conditions</Link>
            <Link href="/returns-policy">Returns &amp; Refunds</Link>
          </div>
        </div>

        <div className="footer-legal">
          <p>
            Velluvia &middot; Based in Ebbsfleet, Kent, United Kingdom &middot; Contact:
            hello@velluvia.co.uk
          </p>
        </div>

        <div className="footer-bottom">
          <span>&copy; {new Date().getFullYear()} Velluvia. All rights reserved.</span>
          <span>Curated with love.</span>
        </div>
      </div>
    </footer>
  );
}
