import Link from "next/link";
import { Collection } from "@/lib/types";

export default function CollectionCard({ collection }: { collection: Collection }) {
  return (
    <Link href={`/collections/${collection.slug}`} className="collection-card">
      {collection.comingSoon && <span className="coming-soon-badge">Coming Soon</span>}
      {collection.image ? (
        <img src={collection.image} alt={collection.name} />
      ) : (
        <div className="collection-monogram" aria-hidden="true">
          <span>V</span>
        </div>
      )}
      <div className="cc-body">
        <span className="eyebrow">Collection</span>
        <h3>{collection.name}</h3>
        <p>{collection.tagline}</p>
      </div>
    </Link>
  );
}
